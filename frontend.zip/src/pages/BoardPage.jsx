import { useModal } from "../contexts/ModalContext";
import { useAuth } from "../contexts/AuthContext";
import CreateBoardModalContent from "../components/modals/CreateBoardModalContent";
import { useEffect } from "react";

const dummyBoards = [
	{
		id: 1,
		name: "Final Project",
		description: "Board untuk tracking task final project",
		members: 4,
		cards: 18,
	},
	{
		id: 2,
		name: "Signban Development",
		description: "Realtime Kanban + AI checklist",
		members: 2,
		cards: 9,
	},
];

export default function BoardPage() {
	const modal = useModal();
	const { currentUser } = useAuth();

	const openCreateBoardModal = () => {
		modal.open({
			title: "Create Board",
			size: "lg",
			content: ({ close }) => <CreateBoardModalContent onClose={close} />,
		});
	};

	useEffect(() => {
		document.title = "Dashboard | Signban";
	}, []);

	return (
		<section className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
			<div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
				<div>
					<div className="mb-3 flex flex-wrap gap-2">
						<span className="badge badge-primary">Dashboard</span>
					</div>

					<h1 className="text-4xl font-black text-base-content">
						Welcome back{currentUser?.email ? `, ${currentUser.email}` : ""}
					</h1>
				</div>

				<button
					type="button"
					onClick={openCreateBoardModal}
					className="btn btn-primary"
				>
					Create Board
				</button>
			</div>

			<div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
				{dummyBoards.map((board) => (
					<article
						key={board.id}
						className="card border border-base-300 bg-base-100 shadow-sm transition hover:-translate-y-0.5 hover:shadow-xl"
					>
						<div className="card-body">
							<div className="flex items-start justify-between gap-4">
								<div>
									<h2 className="card-title text-2xl font-black">
										{board.name}
									</h2>
									<p className="mt-2 text-sm leading-relaxed text-base-content/60">
										{board.description}
									</p>
								</div>

								<div className="badge badge-primary badge-outline">Board</div>
							</div>

							<div className="mt-5 grid grid-cols-2 gap-3">
								<div className="rounded-2xl bg-base-200 p-4">
									<p className="text-2xl font-black">{board.members}</p>
									<p className="text-xs text-base-content/50">Members</p>
								</div>

								<div className="rounded-2xl bg-base-200 p-4">
									<p className="text-2xl font-black">{board.cards}</p>
									<p className="text-xs text-base-content/50">Cards</p>
								</div>
							</div>

							<div className="card-actions mt-5 justify-end">
								<button type="button" className="btn btn-outline btn-sm">
									Open Board
								</button>
							</div>
						</div>
					</article>
				))}
			</div>
		</section>
	);
}
